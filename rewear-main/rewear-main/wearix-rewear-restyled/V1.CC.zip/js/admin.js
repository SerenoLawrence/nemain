// ============================================================
// admin.js — Admin dashboard logic
// Used on: admin.html
// PIN: 1234 (change in Supabase admin_sessions table)
// ============================================================

// ---- PIN GATE ----
const CORRECT_PIN = '1234'; // simple client check — real hash check via Supabase
const adminGate      = document.getElementById('adminGate');
const adminDashboard = document.getElementById('adminDashboard');
const pinDigits      = document.querySelectorAll('.pin-digit');
const pinError       = document.getElementById('pinError');
const pinSubmitBtn   = document.getElementById('pinSubmitBtn');

// Auto-advance PIN digits
pinDigits.forEach((input, i) => {
  input.addEventListener('input', () => {
    input.value = input.value.replace(/\D/g, '');
    if (input.value && i < pinDigits.length - 1) pinDigits[i + 1].focus();
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Backspace' && !input.value && i > 0) pinDigits[i - 1].focus();
  });
});

function getPin() { return [...pinDigits].map(d => d.value).join(''); }

function unlockAdmin() {
  adminGate.classList.add('hidden');
  adminDashboard.classList.remove('hidden');
  sessionStorage.setItem('rewear_admin', '1');
  loadOverviewStats();
  startClock();
}

// Check if already logged in this session
if (sessionStorage.getItem('rewear_admin') === '1') unlockAdmin();

pinSubmitBtn.addEventListener('click', checkPin);
document.addEventListener('keydown', e => { if (e.key === 'Enter') checkPin(); });

function checkPin() {
  const pin = getPin();
  if (pin === CORRECT_PIN) {
    unlockAdmin();
  } else {
    pinError.classList.remove('hidden');
    pinDigits.forEach(d => { d.value = ''; d.classList.add('pin-error-shake'); });
    setTimeout(() => pinDigits.forEach(d => d.classList.remove('pin-error-shake')), 500);
    pinDigits[0].focus();
  }
}

document.getElementById('adminLogoutBtn')?.addEventListener('click', () => {
  sessionStorage.removeItem('rewear_admin');
  adminDashboard.classList.add('hidden');
  adminGate.classList.remove('hidden');
  pinDigits.forEach(d => d.value = '');
  pinDigits[0].focus();
});

// ---- CLOCK ----
function startClock() {
  const el = document.getElementById('adminClock');
  if (!el) return;
  const tick = () => { el.textContent = new Date().toLocaleTimeString(); };
  tick(); setInterval(tick, 1000);
}

// ---- TAB SWITCHING ----
document.querySelectorAll('.dash-nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const tab = link.dataset.tab;
    document.querySelectorAll('.dash-nav-link').forEach(l => l.classList.remove('active'));
    document.querySelectorAll('.dash-tab').forEach(t => t.classList.remove('active'));
    link.classList.add('active');
    document.getElementById(`tab-${tab}`)?.classList.add('active');
    document.getElementById('dashPageTitle').textContent = link.textContent.trim();
    if (tab === 'sellers')  loadSellers();
    if (tab === 'listings') loadListings();
    if (tab === 'orders')   loadOrders();
  });
});

// ---- OVERVIEW STATS ----
async function loadOverviewStats() {
  const [
    { count: pendingSellers },
    { count: pendingListings },
    { count: totalOrders },
    { count: totalProducts }
  ] = await Promise.all([
    db.from('sellers').select('*', { count: 'exact', head: true }).eq('verified', false),
    db.from('products').select('*', { count: 'exact', head: true }).eq('status', 'pending'),
    db.from('orders').select('*', { count: 'exact', head: true }),
    db.from('products').select('*', { count: 'exact', head: true })
  ]);

  document.getElementById('statPendingSellers').textContent  = pendingSellers ?? 0;
  document.getElementById('statPendingListings').textContent = pendingListings ?? 0;
  document.getElementById('statTotalOrders').textContent     = totalOrders ?? 0;
  document.getElementById('statTotalProducts').textContent   = totalProducts ?? 0;

  // Attention list
  const { data: pendingSellerList } = await db.from('sellers').select('*').eq('verified', false).limit(3);
  const { data: pendingListingList } = await db.from('products').select('*').eq('status', 'pending').limit(3);
  const attentionList = document.getElementById('attentionList');

  const items = [
    ...(pendingSellerList || []).map(s => `
      <div class="admin-attention-row">
        <span class="dash-badge dash-badge-pending">Seller</span>
        <span class="admin-attention-name">${s.business_name}</span>
        <span class="admin-attention-meta">${s.email}</span>
        <button class="admin-btn admin-btn-approve" onclick="verifySeller('${s.id}', true)">Approve</button>
        <button class="admin-btn admin-btn-reject"  onclick="promptRejectSeller('${s.id}')">Reject</button>
      </div>`),
    ...(pendingListingList || []).map(p => `
      <div class="admin-attention-row">
        <span class="dash-badge" style="background:rgba(17,17,17,0.1);color:#555">Listing</span>
        <span class="admin-attention-name">${p.name}</span>
        <span class="admin-attention-meta">$${parseFloat(p.price).toFixed(2)}</span>
        <button class="admin-btn admin-btn-approve" onclick="approveListing('${p.id}')">Approve</button>
        <button class="admin-btn admin-btn-reject"  onclick="promptRejectListing('${p.id}')">Reject</button>
      </div>`)
  ];

  attentionList.innerHTML = items.length ? items.join('') : '<p class="dash-empty">Nothing needs attention right now.</p>';
}

// ---- SELLERS TAB ----
async function loadSellers() {
  const list = document.getElementById('sellersList');
  list.innerHTML = '<p class="dash-empty">Loading…</p>';

  const statusFilter = document.getElementById('sellerStatusFilter')?.value || 'all';
  const search = document.getElementById('sellerSearch')?.value.toLowerCase() || '';

  let query = db.from('sellers').select('*').order('created_at', { ascending: false });
  if (statusFilter === 'verified') query = query.eq('verified', true);
  if (statusFilter === 'pending')  query = query.eq('verified', false);

  const { data, error } = await query;
  if (error) { list.innerHTML = '<p class="dash-empty">Could not load sellers.</p>'; console.error('[admin] loadSellers:', error.message); return; }

  const filtered = search ? data.filter(s => s.business_name?.toLowerCase().includes(search) || s.email?.toLowerCase().includes(search)) : data;

  list.innerHTML = filtered.length
    ? filtered.map(s => `
        <div class="admin-card">
          <div class="admin-card-header">
            <div>
              <h3 class="admin-card-title">${s.business_name}</h3>
              <p class="admin-card-meta">${s.email}${s.phone ? ` · ${s.phone}` : ''}</p>
              <p class="admin-card-meta">Applied: ${formatDate(s.created_at)}</p>
              ${s.description ? `<p class="admin-card-desc">${s.description}</p>` : ''}
            </div>
            <span class="dash-badge ${s.verified ? 'dash-badge-verified' : 'dash-badge-pending'}">${s.verified ? 'Verified' : 'Pending'}</span>
          </div>
          ${s.rejection_reason ? `<p class="admin-rejection-note">Rejected: ${s.rejection_reason}</p>` : ''}
          <div class="admin-card-actions">
            ${!s.verified ? `
              <button class="admin-btn admin-btn-approve" onclick="verifySeller('${s.id}', true)">✓ Approve Seller</button>
              <button class="admin-btn admin-btn-reject"  onclick="promptRejectSeller('${s.id}')">✕ Reject</button>
            ` : `
              <button class="admin-btn admin-btn-reject" onclick="verifySeller('${s.id}', false)">Revoke Verification</button>
            `}
          </div>
        </div>`).join('')
    : '<p class="dash-empty">No sellers found.</p>';
}

document.getElementById('sellerStatusFilter')?.addEventListener('change', loadSellers);
document.getElementById('sellerSearch')?.addEventListener('input', loadSellers);

// ---- VERIFY / REJECT SELLER ----
async function verifySeller(id, approve) {
  showLoadingModal(approve ? 'Approving Seller…' : 'Revoking…', 'Updating seller status.');
  const { error } = await db.from('sellers').update({
    verified: approve,
    verified_at: approve ? new Date().toISOString() : null,
    rejection_reason: approve ? null : undefined
  }).eq('id', id);
  hideLoadingModal();
  if (error) { showError('Update Failed', error.message); console.error('[admin] verifySeller:', error.message); return; }
  showSuccess(approve ? 'Seller Approved!' : 'Verification Revoked', approve ? 'The seller can now list products.' : 'Seller access has been revoked.', 'Got it');
  loadSellers();
  loadOverviewStats();
}

async function promptRejectSeller(id) {
  const reason = prompt('Reason for rejection (will be shown to seller):');
  if (reason === null) return;
  showLoadingModal('Rejecting…', 'Updating seller status.');
  const { error } = await db.from('sellers').update({ verified: false, rejection_reason: reason || 'Application rejected.' }).eq('id', id);
  hideLoadingModal();
  if (error) { showError('Update Failed', error.message); return; }
  showSuccess('Seller Rejected', 'The seller has been notified.', 'Got it');
  loadSellers();
  loadOverviewStats();
}

// ---- LISTINGS TAB ----
async function loadListings() {
  const list = document.getElementById('listingsList');
  list.innerHTML = '<p class="dash-empty">Loading…</p>';

  const statusFilter = document.getElementById('listingStatusFilter')?.value || 'pending';
  const search = document.getElementById('listingSearch')?.value.toLowerCase() || '';

  let query = db.from('products').select('*').order('created_at', { ascending: false });
  if (statusFilter !== 'all') query = query.eq('status', statusFilter);

  const { data, error } = await query;
  if (error) { list.innerHTML = '<p class="dash-empty">Could not load listings.</p>'; console.error('[admin] loadListings:', error.message); return; }

  const filtered = search ? data.filter(p => p.name?.toLowerCase().includes(search)) : data;

  list.innerHTML = filtered.length
    ? filtered.map(p => `
        <div class="admin-card">
          <div class="admin-card-header">
            <div class="admin-card-img-wrap">
              <img src="${p.image_url}" alt="${p.name}" class="admin-card-img">
            </div>
            <div style="flex:1">
              <h3 class="admin-card-title">${p.name}</h3>
              <p class="admin-card-meta">$${parseFloat(p.price).toFixed(2)} · ${p.category} · Sizes: ${(p.sizes||[]).join(', ')}</p>
              <p class="admin-card-meta">Added: ${formatDate(p.created_at)}</p>
              ${p.description ? `<p class="admin-card-desc">${p.description}</p>` : ''}
            </div>
            <span class="dash-badge ${p.status === 'approved' ? 'dash-badge-verified' : p.status === 'rejected' ? 'dash-badge-rejected' : 'dash-badge-pending'}">${p.status}</span>
          </div>
          ${p.rejection_reason ? `<p class="admin-rejection-note">Rejected: ${p.rejection_reason}</p>` : ''}
          <div class="admin-card-actions">
            ${p.status !== 'approved' ? `<button class="admin-btn admin-btn-approve" onclick="approveListing('${p.id}')">✓ Approve Listing</button>` : ''}
            ${p.status !== 'rejected' ? `<button class="admin-btn admin-btn-reject"  onclick="promptRejectListing('${p.id}')">✕ Reject</button>` : ''}
            ${p.status === 'rejected' ? `<button class="admin-btn admin-btn-approve" onclick="approveListing('${p.id}')">↺ Re-approve</button>` : ''}
          </div>
        </div>`).join('')
    : '<p class="dash-empty">No listings found.</p>';
}

document.getElementById('listingStatusFilter')?.addEventListener('change', loadListings);
document.getElementById('listingSearch')?.addEventListener('input', loadListings);

// ---- APPROVE / REJECT LISTING ----
async function approveListing(id) {
  showLoadingModal('Approving…', 'Making listing live in the shop.');
  const { error } = await db.from('products').update({ status: 'approved', in_stock: true, rejection_reason: null }).eq('id', id);
  hideLoadingModal();
  if (error) { showError('Update Failed', error.message); console.error('[admin] approveListing:', error.message); return; }
  showSuccess('Listing Approved!', 'The product is now live in the shop.', 'Got it');
  loadListings();
  loadOverviewStats();
}

async function promptRejectListing(id) {
  const reason = prompt('Reason for rejection (will be shown to seller):');
  if (reason === null) return;
  showLoadingModal('Rejecting…', 'Updating listing status.');
  const { error } = await db.from('products').update({ status: 'rejected', in_stock: false, rejection_reason: reason || 'Listing rejected.' }).eq('id', id);
  hideLoadingModal();
  if (error) { showError('Update Failed', error.message); return; }
  showSuccess('Listing Rejected', 'The seller will see the rejection reason.', 'Got it');
  loadListings();
  loadOverviewStats();
}

// ---- ORDERS TAB ----
async function loadOrders() {
  const list = document.getElementById('adminOrdersList');
  list.innerHTML = '<p class="dash-empty">Loading…</p>';

  const statusFilter = document.getElementById('orderStatusFilter')?.value || 'all';
  let query = db.from('orders').select('*').order('created_at', { ascending: false });
  if (statusFilter !== 'all') query = query.eq('status', statusFilter);

  const { data, error } = await query;
  if (error) { list.innerHTML = '<p class="dash-empty">Could not load orders.</p>'; console.error('[admin] loadOrders:', error.message); return; }

  list.innerHTML = data?.length
    ? data.map(o => `
        <div class="dash-order-row">
          <div>
            <p class="dash-order-name">${o.buyer_name}</p>
            <p class="dash-order-meta">${o.buyer_email} · Size: ${o.size_selected || '—'} · $${parseFloat(o.total_price || 0).toFixed(2)}</p>
            <p class="dash-order-meta">${formatDate(o.created_at)}</p>
          </div>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <span class="dash-order-status status-${o.status}">${o.status}</span>
            <select class="sort-select" style="padding:6px 12px;font-size:12px" onchange="updateOrderStatus('${o.id}', this.value)">
              <option value="">Update status</option>
              <option value="pending">Pending</option>
              <option value="confirmed">Confirmed</option>
              <option value="shipped">Shipped</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>`).join('')
    : '<p class="dash-empty">No orders found.</p>';
}

document.getElementById('orderStatusFilter')?.addEventListener('change', loadOrders);

async function updateOrderStatus(id, status) {
  if (!status) return;
  const { error } = await db.from('orders').update({ status }).eq('id', id);
  if (error) { showError('Update Failed', error.message); return; }
  showSuccess('Order Updated', `Status changed to ${status}.`, 'Got it');
  loadOrders();
}

// Expose functions globally for inline onclick handlers
window.verifySeller       = verifySeller;
window.promptRejectSeller = promptRejectSeller;
window.approveListing     = approveListing;
window.promptRejectListing = promptRejectListing;
window.updateOrderStatus  = updateOrderStatus;
