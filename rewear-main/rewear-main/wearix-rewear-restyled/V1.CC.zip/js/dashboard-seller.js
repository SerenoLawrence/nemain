// ============================================================
// dashboard-seller.js — Seller dashboard logic
// Used on: dashboard-seller.html
// ============================================================

// ---- TAB SWITCHING ----
document.querySelectorAll('.dash-nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const tab = link.dataset.tab;
    document.querySelectorAll('.dash-nav-link').forEach(l => l.classList.remove('active'));
    document.querySelectorAll('.dash-tab').forEach(t => t.classList.remove('active'));
    link.classList.add('active');
    const tabEl = document.getElementById(`tab-${tab}`);
    if (tabEl) tabEl.classList.add('active');
    const titleEl = document.getElementById('dashPageTitle');
    if (titleEl) titleEl.textContent = link.textContent.trim();
    if (tab === 'listings') loadSellerListings();
    if (tab === 'orders')   loadSellerOrders();
  });
});

// Shortcut: Add Listing button
document.getElementById('addProductBtn')?.addEventListener('click', () => {
  document.querySelector('[data-tab="add"]')?.click();
});

// ---- OVERVIEW STATS ----
async function loadOverviewStats() {
  const { count: listingCount } = await db.from('products').select('*', { count: 'exact', head: true });
  const { count: orderCount }   = await db.from('orders').select('*', { count: 'exact', head: true });
  const { count: pendingCount } = await db.from('orders').select('*', { count: 'exact', head: true }).eq('status', 'pending');

  const el = id => document.getElementById(id);
  if (el('statListings')) el('statListings').textContent = listingCount ?? 0;
  if (el('statOrders'))   el('statOrders').textContent   = orderCount ?? 0;
  if (el('statPending'))  el('statPending').textContent  = pendingCount ?? 0;

  // Recent orders preview
  const { data: recentOrders } = await db.from('orders').select('*').order('created_at', { ascending: false }).limit(5);
  const list = document.getElementById('recentOrdersList');
  if (list) {
    list.innerHTML = recentOrders?.length
      ? recentOrders.map(o => orderRowHTML(o)).join('')
      : '<p class="dash-empty">No orders yet.</p>';
  }
}

// ---- LISTINGS TAB ----
async function loadSellerListings() {
  const grid = document.getElementById('sellerListingsGrid');
  if (!grid) return;
  grid.innerHTML = '<p class="dash-empty">Loading…</p>';

  const sort = document.getElementById('listingSort')?.value || 'newest';
  let query = db.from('products').select('*');
  if (sort === 'price_asc')  query = query.order('price', { ascending: true });
  if (sort === 'price_desc') query = query.order('price', { ascending: false });
  if (sort === 'newest')     query = query.order('created_at', { ascending: false });

  const { data, error } = await query;
  if (error) { grid.innerHTML = '<p class="dash-empty">Could not load listings.</p>'; console.error('[seller] loadListings:', error.message); return; }

  const search = document.getElementById('listingSearch')?.value.toLowerCase() || '';
  const filtered = search ? data.filter(p => p.name.toLowerCase().includes(search)) : data;

  grid.innerHTML = filtered.length
    ? filtered.map(p => `
        <div class="product-card" style="cursor:default">
          <div class="product-image"><img src="${p.image_url}" alt="${p.name}" loading="lazy"></div>
          <div class="product-info">
            <h3 class="product-name">${p.name}</h3>
            <p class="product-price">$${parseFloat(p.price).toFixed(2)}</p>
            <div class="product-sizes">${(p.sizes||[]).map(s=>`<span class="size-tag">${s}</span>`).join('')}</div>
            <span class="${p.in_stock ? 'pd-instock' : 'pd-outstock'}">${p.in_stock ? '✓ In Stock' : '✕ Out of Stock'}</span>
          </div>
        </div>`).join('')
    : '<p class="dash-empty">No listings found.</p>';
}

document.getElementById('listingSearch')?.addEventListener('input', loadSellerListings);
document.getElementById('listingSort')?.addEventListener('change', loadSellerListings);

// ---- ORDERS TAB ----
function orderRowHTML(o) {
  return `
    <div class="dash-order-row">
      <div>
        <p class="dash-order-name">${o.buyer_name}</p>
        <p class="dash-order-meta">${o.buyer_email} · Size: ${o.size_selected || '—'} · $${parseFloat(o.total_price||0).toFixed(2)}</p>
        <p class="dash-order-meta">${new Date(o.created_at).toLocaleDateString()}</p>
      </div>
      <span class="dash-order-status status-${o.status}">${o.status}</span>
    </div>`;
}

async function loadSellerOrders() {
  const list = document.getElementById('sellerOrdersList');
  if (!list) return;
  list.innerHTML = '<p class="dash-empty">Loading…</p>';

  const statusFilter = document.getElementById('orderStatusFilter')?.value || 'all';
  let query = db.from('orders').select('*').order('created_at', { ascending: false });
  if (statusFilter !== 'all') query = query.eq('status', statusFilter);

  const { data, error } = await query;
  if (error) { list.innerHTML = '<p class="dash-empty">Could not load orders.</p>'; console.error('[seller] loadOrders:', error.message); return; }
  list.innerHTML = data?.length ? data.map(o => orderRowHTML(o)).join('') : '<p class="dash-empty">No orders found.</p>';
}

document.getElementById('orderStatusFilter')?.addEventListener('change', loadSellerOrders);

// ---- ADD PRODUCT FORM ----
document.getElementById('addProductForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  const sizes = [...document.querySelectorAll('.size-checkboxes input:checked')].map(cb => cb.value);
  const payload = {
    name:             document.getElementById('newName').value.trim(),
    price:            parseFloat(document.getElementById('newPrice').value),
    category:         document.getElementById('newCategory').value,
    suggested_price:  parseFloat(document.getElementById('newSuggestedPrice').value) || null,
    image_url:        document.getElementById('newImageUrl').value.trim(),
    description:      document.getElementById('newDescription').value.trim(),
    sizes:            sizes.length ? sizes : ['S', 'M', 'L'],
    in_stock:         true
  };
  showLoadingModal('Publishing…', 'Adding your product to the store.');
  const { error } = await db.from('products').insert(payload);
  hideLoadingModal();
  if (error) { showError('Failed to Publish', error.message); console.error('[seller] addProduct:', error.message); }
  else { showSuccess('Listing Published!', `${payload.name} is now live in the shop.`, 'Got it'); document.getElementById('addProductForm').reset(); }
});

// ---- SELLER PROFILE FORM ----
document.getElementById('sellerProfileForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  const payload = {
    business_name: document.getElementById('bizName').value.trim(),
    email:         document.getElementById('bizEmail').value.trim(),
    phone:         document.getElementById('bizPhone').value.trim(),
    description:   document.getElementById('bizDesc').value.trim()
  };
  showLoadingModal('Saving…', 'Updating your seller profile.');
  const { error } = await db.from('sellers').insert(payload);
  hideLoadingModal();
  if (error) {
    if (error.code === '23505') showError('Email Taken', 'This email is already registered as a seller.');
    else showError('Save Failed', error.message);
    console.error('[seller] saveProfile:', error.message);
  } else {
    showSuccess('Profile Saved!', 'Your seller profile has been submitted for review.', 'Got it');
  }
});

// ---- INIT ----
loadOverviewStats();
