# REWEAR Project Structure

## ✅ Complete Organization (Updated)

```
rewear_verification_SIGNUP-main/rewearnew/
│
├── 📄 index.html                    # Homepage (ROOT FILE)
├── 📄 supabase.js                   # Supabase configuration
├── 📄 package.json                  # Dependencies
├── 📄 README.md                     # Project documentation
├── 📄 PROJECT_STRUCTURE.md          # This file
│
├── 📁 css/                          # Stylesheets
│   └── style.css                    # Main stylesheet (moved from root)
│
├── 📁 js/                           # JavaScript modules (already organized)
│   ├── core.js                      # Core utilities & modals
│   ├── local-auth.js                # Authentication system
│   ├── auth-nav.js                  # Navigation auth handler
│   ├── validators.js                # Form validators
│   ├── shop.js                      # Shop page logic
│   ├── product.js                   # Product detail logic
│   ├── dashboard-buyer.js           # Buyer dashboard
│   ├── dashboard-seller.js          # Seller dashboard
│   ├── admin.js                     # Admin panel
│   ├── blog.js                      # Blog functionality
│   ├── contact.js                   # Contact form
│   ├── image-upload.js              # Image upload utility
│   ├── confirm-modal.js             # Confirmation modals
│   ├── shop-old.js                  # Legacy shop code
│   └── script.js                    # Legacy scripts (moved from root)
│
├── 📁 pages/                        # HTML pages (NEW FOLDER)
│   ├── shop.html                    # Shop/Browse page
│   ├── product.html                 # Product detail
│   ├── wishlist.html                # Wishlist (modern design) ✨
│   ├── login.html                   # Login page
│   ├── signup.html                  # Signup page
│   ├── forgot-password.html         # Password reset request
│   ├── reset-password.html          # Password reset form
│   ├── dashboard-buyer.html         # Buyer dashboard
│   ├── dashboard-seller.html        # Seller dashboard
│   ├── admin.html                   # Admin panel
│   ├── about.html                   # About page
│   ├── blog.html                    # Blog listing
│   ├── contact.html                 # Contact page
│   └── 404.html                     # Error page
│
├── 📁 assets/                       # Static assets (already organized)
│   └── images/                      # All images
│       ├── hero-seasonal-depth.jpg
│       ├── leather-bomber-jacket.jpg
│       ├── textured-knitted-shirt.jpg
│       └── ... (more images)
│
├── 📁 sql/                          # Database schemas (already organized)
│   ├── 01_store.sql
│   ├── 02_users.sql
│   ├── 03_admin.sql
│   ├── 04_marketplace.sql
│   ├── 05_critical_fixes.sql
│   └── rewear_full_setup.sql
│
└── 📁 tests/                        # Test & demo files (NEW FOLDER)
    ├── test-auth-flow.html
    ├── test-wishlist-fix.html
    ├── test-wishlist-navigation.html
    ├── test-signup-debug.html
    ├── local-auth-demo.html
    ├── shop-old.html
    └── rewear-lite.html
```

## 🔄 What Changed

### Files Moved:
1. ✅ `style.css` → `css/style.css`
2. ✅ `script.js` → `js/script.js`
3. ✅ All HTML pages (except index.html) → `pages/`
4. ✅ Test files → `tests/`

### Files Updated:
- ✅ **index.html** - Updated all paths to new structure
- ✅ **All pages/** - Updated to use relative paths (`../`)
- ✅ **js/auth-nav.js** - Made path-aware
- ✅ **js/local-auth.js** - Smart redirects based on location
- ✅ **pages/404.html** - Fixed script.js reference

## 📍 Path Reference

### From Root (index.html):
```html
<link rel="stylesheet" href="css/style.css">
<script src="js/core.js"></script>
<a href="pages/shop.html">Shop</a>
<img src="assets/images/hero.jpg">
```

### From Pages Folder:
```html
<link rel="stylesheet" href="../css/style.css">
<script src="../js/core.js"></script>
<a href="../index.html">Home</a>
<a href="shop.html">Shop</a>
<img src="../assets/images/hero.jpg">
```

## 🎯 Benefits

1. **Clean Root Directory** - Only essential files at root level
2. **Organized Structure** - Easy to find files by type
3. **Professional Layout** - Industry-standard organization
4. **Easy Maintenance** - Clear separation of concerns
5. **Scalable** - Easy to add new pages/features

## 🚀 Quick Start

1. Open `index.html` in browser
2. Navigate to any page - all links work!
3. Modern wishlist at `pages/wishlist.html`

## 📝 Notes

- JavaScript files are **path-aware** - they detect if running from root or pages folder
- All navigation works correctly from any location
- Test files are isolated in `tests/` folder
- Legacy code (script.js, shop-old.js) kept for reference

---

**Last Updated:** Project reorganization complete
**Status:** ✅ All files organized and working
