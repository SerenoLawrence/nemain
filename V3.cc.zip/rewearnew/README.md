# REWEAR - Premium Fashion E-Commerce

A modern, premium fashion e-commerce platform built with vanilla HTML, CSS, and JavaScript.

## 📁 Project Structure

```
rewear_verification_SIGNUP-main/rewearnew/
├── index.html              # Homepage (root file)
├── supabase.js            # Supabase configuration
├── package.json           # Project dependencies
│
├── css/                   # Stylesheets
│   └── style.css         # Main stylesheet
│
├── js/                    # JavaScript modules
│   ├── core.js           # Core utilities
│   ├── local-auth.js     # Authentication system
│   ├── auth-nav.js       # Navigation auth handler
│   ├── skeleton-loader.js # Skeleton loading helper
│   ├── shop.js           # Shop page logic
│   ├── product.js        # Product page logic
│   ├── script.js         # Legacy scripts (being phased out)
│   ├── dashboard-buyer.js
│   ├── dashboard-seller.js
│   ├── admin.js
│   ├── blog.js
│   ├── contact.js
│   ├── validators.js
│   └── image-upload.js
│
├── pages/                 # HTML pages
│   ├── shop.html         # Shop/Browse page
│   ├── product.html      # Product detail page
│   ├── wishlist.html     # Wishlist page (modern design)
│   ├── login.html        # Login page
│   ├── signup.html       # Signup page
│   ├── dashboard-buyer.html
│   ├── dashboard-seller.html
│   ├── about.html
│   ├── blog.html
│   ├── contact.html
│   ├── admin.html
│   ├── forgot-password.html
│   ├── reset-password.html
│   └── 404.html
│
├── assets/                # Static assets
│   └── images/           # Image files
│
├── sql/                   # Database schemas
│   ├── 01_store.sql
│   ├── 02_users.sql
│   ├── 03_admin.sql
│   ├── 04_marketplace.sql
│   ├── 05_critical_fixes.sql
│   └── rewear_full_setup.sql
│
└── tests/                 # Test and demo files
    ├── test-auth-flow.html
    ├── test-wishlist-fix.html
    ├── test-wishlist-navigation.html
    ├── skeleton-demo.html
    ├── local-auth-demo.html
    └── rewear-lite.html
```

## 🚀 Getting Started

1. **Open the project**: Navigate to `rewear_verification_SIGNUP-main/rewearnew/`
2. **Start with**: Open `index.html` in your browser
3. **Configure Supabase**: Update `supabase.js` with your credentials

## 🎨 Design System

- **Colors**: Black (#000), White (#FFF), Gray scale
- **Typography**: Syne (display), DM Sans (body)
- **Style**: Modern, minimal, premium fashion aesthetic

## 📄 Key Pages

- **Homepage** (`index.html`): Landing page with hero, categories, stats
- **Shop** (`pages/shop.html`): Product browsing with filters, search, sort
- **Wishlist** (`pages/wishlist.html`): Modern wishlist with stats and management
- **Product** (`pages/product.html`): Product detail page
- **Dashboards**: Buyer and seller dashboards

## 🔐 Authentication

- Local storage-based authentication system
- No email verification required
- Session persistence
- Role-based access (buyer/seller)

## 🛠️ Features

- ✅ Product browsing with filters
- ✅ Search functionality
- ✅ Wishlist management
- ✅ User authentication
- ✅ Buyer/Seller dashboards
- ✅ Skeleton loading states
- ✅ Responsive design
- ✅ Modern UI/UX

## 📝 Notes

- All pages in `pages/` folder use relative paths (`../`)
- JavaScript modules are path-aware (detect root vs pages folder)
- CSS is centralized in `css/style.css`
- Images are in `assets/images/`
- Skeleton loading provides professional loading states

## 📚 Documentation

- **PROJECT_STRUCTURE.md** - Detailed project organization
- **SHOP_INTEGRATION_SUMMARY.md** - Shop page implementation
- **SIGNUP_FIX_GUIDE.md** - Authentication fixes
- **SKELETON_LOADING_SUMMARY.md** - Skeleton loading implementation

## 🔗 Navigation Paths

From **root** (index.html):
- Pages: `pages/shop.html`
- CSS: `css/style.css`
- JS: `js/core.js`
- Images: `assets/images/`

From **pages** folder:
- Root: `../index.html`
- CSS: `../css/style.css`
- JS: `../js/core.js`
- Images: `../assets/images/`

## 💡 Development

- Edit styles in `css/style.css`
- Add new pages to `pages/` folder
- JavaScript modules in `js/` folder
- Test files in `tests/` folder

---

**REWEAR** - Timeless Design, Modern Wearability
