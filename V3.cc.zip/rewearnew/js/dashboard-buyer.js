// ============================================================
// dashboard-buyer.js — Buyer dashboard logic
// Used on: dashboard-buyer.html
// ============================================================

// ---- TAB SWITCHING ----
document.querySelectorAll('.dash-nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const tab = link.dataset.tab;
    document.querySelectorAll('.dash-nav-link').forEach(l => l.classList.remove('active'));
    document.querySelectorAll('.dash-tab').forEach(t => t.classList.remove('active'));
    link.classList.add('active');
    const tabEl = document.getElementById(`tab-${tab}`);
    if (tabEl) tabEl.classList.add('active');
    const titleEl = document.getElementById('dashPageTitle');
    if (titleEl) titleEl.textContent = link.textContent.trim();
    
    if (tab === 'orders') loadBuyerOrders();
    if (tab === 'addresses') loadBuyerAddresses();
  });
});

// ---- OVERVIEW STATS ----
async function loadOverviewStats() {
  const currentUserId = authManager.getCurrentUser()?.id;
  if (!currentUserId) return;

  try {
    const { count: totalOrders } = await db
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('buyer_user_id', currentUserId);

    const { count: pendingOrders } = await db
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('buyer_user_id', currentUserId)
      .eq('status', 'pending');

    const { count: deliveredOrders } = await db
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('buyer_user_id', currentUserId)
      .eq('status', 'delivered');

    // Calculate total spent
    const { data: orders } = await db
      .from('orders')
      .select('total_price')
      .eq('buyer_user_id', currentUserId);

    const totalSpent = (orders || []).reduce((sum, order) => sum + parseFloat(order.total_price || 0), 0);

    // Update stats
    const el = id => document.getElementById(id);
    if (el('statTotalOrders')) el('statTotalOrders').textContent = totalOrders ?? 0;
    if (el('statPendingOrders')) el('statPendingOrders').textContent = pendingOrders ?? 0;
    if (el('statDeliveredOrders')) el('statDeliveredOrders').textContent = deliveredOrders ?? 0;
    if (el('statTotalSpent')) el('statTotalSpent').textContent = formatPHP(totalSpent);

    // Load recent orders
    const { data: recentOrders } = await db
      .from('orders')
      .select('*, products(name, image_url)')
      .eq('buyer_user_id', currentUserId)
      .order('created_at', { ascending: false })
      .limit(5);

    const list = document.getElementById('recentOrdersList');
    if (list) {
      list.innerHTML = recentOrders?.length
        ? recentOrders.map(o => orderRowHTML(o)).join('')
        : '<p class="dash-empty">No orders yet. <a href="shop.html">Start shopping!</a></p>';
    }

  } catch (error) {
    console.error('[buyer] loadOverviewStats:', error.message);
  }
}

// ---- ORDERS TAB ----
function orderRowHTML(o) {
  const productName = o.products?.name || 'Product';
  const productImage = o.products?.image_url || '';
  
  return `
    <div class="dash-order-row">
      <div style="display: flex; align-items: center; gap: 12px;">
        ${productImage ? `<img src="${productImage}" alt="${productName}" style="width: 48px; height: 48px; object-fit: cover; border-radius: 4px;">` : ''}
        <div>
          <p class="dash-order-name">${productName}</p>
          <p class="dash-order-meta">Size: ${o.size_selected || '—'} · ${formatPHP(o.total_price || 0)}</p>
          <p class="dash-order-meta">${formatDate(o.created_at)}</p>
        </div>
      </div>
      <span class="dash-order-status status-${o.status}">${o.status}</span>
    </div>`;
}

async function loadBuyerOrders() {
  const currentUserId = authManager.getCurrentUser()?.id;
  if (!currentUserId) return;

  const list = document.getElementById('buyerOrdersList');
  if (!list) return;
  
  // Show skeleton loading
  if (window.SkeletonLoader) {
    list.innerHTML = window.SkeletonLoader.generateSkeletonText(5, ['long', 'medium', 'short']);
  } else {
    list.innerHTML = '<p class="dash-empty">Loading…</p>';
  }

  const statusFilter = document.getElementById('orderStatusFilter')?.value || 'all';
  let query = db
    .from('orders')
    .select('*, products(name, image_url)')
    .eq('buyer_user_id', currentUserId)
    .order('created_at', { ascending: false });

  if (statusFilter !== 'all') {
    query = query.eq('status', statusFilter);
  }

  try {
    const { data, error } = await query;
    if (error) throw error;

    const html = data?.length 
      ? data.map(o => orderRowHTML(o)).join('') 
      : '<p class="dash-empty">No orders found.</p>';
    
    // Use fade-in animation
    if (window.SkeletonLoader) {
      window.SkeletonLoader.hideSkeleton(list, html);
    } else {
      list.innerHTML = html;
      list.classList.add('fade-in');
    }
  } catch (error) {
    list.innerHTML = '<p class="dash-empty">Could not load orders.</p>';
    console.error('[buyer] loadBuyerOrders:', error.message);
  }
}

document.getElementById('orderStatusFilter')?.addEventListener('change', loadBuyerOrders);

// ---- PROFILE MANAGEMENT ----
async function loadBuyerProfile() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  try {
    // Get buyer profile from database
    const { data: buyerProfile } = await db
      .from('buyers')
      .select('*')
      .eq('id', currentUser.id)
      .single();

    // Populate form fields
    const nameField = document.getElementById('buyerName');
    const emailField = document.getElementById('buyerEmail');
    const phoneField = document.getElementById('buyerPhone');

    if (nameField) nameField.value = buyerProfile?.name || currentUser.user_metadata?.full_name || '';
    if (emailField) emailField.value = currentUser.email || '';
    if (phoneField) phoneField.value = buyerProfile?.phone || '';

  } catch (error) {
    console.error('[buyer] loadBuyerProfile:', error.message);
  }
}

// ---- PROFILE FORM ----
document.getElementById('buyerProfileForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  const payload = {
    name: document.getElementById('buyerName').value.trim(),
    phone: document.getElementById('buyerPhone').value.trim()
  };

  // Validation
  if (!payload.name || payload.name.length < 2) {
    showError('Validation Error', 'Name must be at least 2 characters');
    return;
  }

  if (payload.phone && !validators.phone(payload.phone)) {
    showError('Validation Error', validationMessages.phone);
    return;
  }

  showLoadingModal('Saving…', 'Updating your profile.');

  try {
    // Update buyer profile
    const { error } = await db
      .from('buyers')
      .upsert({
        id: currentUser.id,
        name: payload.name,
        email: currentUser.email,
        phone: payload.phone,
        updated_at: new Date().toISOString()
      });

    if (error) throw error;

    // Update auth user metadata
    await db.auth.updateUser({
      data: { full_name: payload.name }
    });

    hideLoadingModal();
    showSuccess('Profile Updated!', 'Your profile has been saved successfully.', 'Got it');

  } catch (error) {
    hideLoadingModal();
    showError('Save Failed', error.message);
    console.error('[buyer] saveProfile:', error.message);
  }
});

// ---- ADDRESSES MANAGEMENT ----
async function loadBuyerAddresses() {
  const currentUserId = authManager.getCurrentUser()?.id;
  if (!currentUserId) return;

  const list = document.getElementById('addressesList');
  if (!list) return;

  list.innerHTML = '<p class="dash-empty">Loading…</p>';

  try {
    const { data: addresses, error } = await db
      .from('buyer_addresses')
      .select('*')
      .eq('buyer_id', currentUserId)
      .order('is_default', { ascending: false });

    if (error) throw error;

    if (!addresses || addresses.length === 0) {
      list.innerHTML = '<p class="dash-empty">No addresses saved yet.</p>';
      return;
    }

    list.innerHTML = addresses.map(addr => `
      <div class="dash-address-card">
        <div class="dash-address-header">
          <h4>${addr.label || 'Address'}</h4>
          ${addr.is_default ? '<span class="dash-badge dash-badge-verified">Default</span>' : ''}
        </div>
        <p class="dash-address-text">
          ${addr.street_address}<br>
          ${addr.city}, ${addr.province} ${addr.postal_code}<br>
          ${addr.country || 'Philippines'}
        </p>
        <div class="dash-address-actions">
          <button class="admin-btn admin-btn-approve" onclick="editAddress('${addr.id}')">Edit</button>
          ${!addr.is_default ? `<button class="admin-btn admin-btn-reject" onclick="deleteAddress('${addr.id}')">Delete</button>` : ''}
        </div>
      </div>
    `).join('');

  } catch (error) {
    list.innerHTML = '<p class="dash-empty">Could not load addresses.</p>';
    console.error('[buyer] loadBuyerAddresses:', error.message);
  }
}

// ---- ADDRESS ACTIONS ----
async function editAddress(addressId) {
  // TODO: Implement address editing modal
  showError('Coming Soon', 'Address editing will be available soon.');
}

async function deleteAddress(addressId) {
  if (!confirm('Are you sure you want to delete this address?')) return;

  showLoadingModal('Deleting…', 'Removing address.');

  try {
    const { error } = await db
      .from('buyer_addresses')
      .delete()
      .eq('id', addressId);

    if (error) throw error;

    hideLoadingModal();
    showSuccess('Address Deleted', 'The address has been removed.', 'Got it');
    loadBuyerAddresses();

  } catch (error) {
    hideLoadingModal();
    showError('Delete Failed', error.message);
    console.error('[buyer] deleteAddress:', error.message);
  }
}

document.getElementById('addAddressBtn')?.addEventListener('click', () => {
  // TODO: Implement add address modal
  showError('Coming Soon', 'Adding addresses will be available soon.');
});

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  loadOverviewStats();
});