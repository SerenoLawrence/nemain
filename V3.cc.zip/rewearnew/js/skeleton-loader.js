// ============================================================
// skeleton-loader.js — Reusable Skeleton Loading Components
// ============================================================

/**
 * Generate skeleton product card HTML
 * @param {number} count - Number of skeleton cards to generate
 * @returns {string} HTML string
 */
function generateSkeletonProducts(count = 8) {
  return Array(count).fill(0).map(() => `
    <div class="skeleton-product-card">
      <div class="skeleton-product-image"></div>
      <div class="skeleton-product-content">
        <div class="skeleton-text subtitle"></div>
        <div class="skeleton-text title"></div>
        <div class="skeleton-text price"></div>
        <div style="display: flex; gap: 8px; margin: 12px 0;">
          <div class="skeleton-text short"></div>
          <div class="skeleton-text short"></div>
          <div class="skeleton-text short"></div>
        </div>
        <div class="skeleton-text medium"></div>
      </div>
    </div>
  `).join('');
}

/**
 * Generate skeleton blog card HTML
 * @param {number} count - Number of skeleton cards to generate
 * @returns {string} HTML string
 */
function generateSkeletonBlog(count = 6) {
  return Array(count).fill(0).map(() => `
    <div class="skeleton-blog-card">
      <div class="skeleton-blog-image"></div>
      <div class="skeleton-blog-content">
        <div class="skeleton-text short"></div>
        <div class="skeleton-text title"></div>
        <div class="skeleton-text long"></div>
        <div class="skeleton-text medium"></div>
      </div>
    </div>
  `).join('');
}

/**
 * Generate skeleton wishlist card HTML
 * @param {number} count - Number of skeleton cards to generate
 * @returns {string} HTML string
 */
function generateSkeletonWishlist(count = 6) {
  return Array(count).fill(0).map(() => `
    <div class="skeleton-wishlist-card">
      <div class="skeleton-wishlist-image"></div>
      <div class="skeleton-wishlist-content">
        <div class="skeleton-text subtitle"></div>
        <div class="skeleton-text title"></div>
        <div class="skeleton-text price"></div>
        <div style="display: flex; gap: 12px; margin-top: 20px;">
          <div class="skeleton-button" style="flex: 1;"></div>
          <div class="skeleton-button" style="width: 100px;"></div>
        </div>
      </div>
    </div>
  `).join('');
}

/**
 * Generate skeleton product detail HTML
 * @returns {string} HTML string
 */
function generateSkeletonProductDetail() {
  return `
    <div class="skeleton-product-detail">
      <div class="skeleton-detail-image"></div>
      <div class="skeleton-detail-content">
        <div class="skeleton-text short"></div>
        <div class="skeleton-text title" style="height: 32px; width: 90%;"></div>
        <div class="skeleton-text medium"></div>
        <div class="skeleton-text price" style="height: 28px; width: 50%;"></div>
        <div class="skeleton-text long"></div>
        <div class="skeleton-text long"></div>
        <div class="skeleton-text medium"></div>
        <div class="skeleton-sizes">
          <div class="skeleton-size"></div>
          <div class="skeleton-size"></div>
          <div class="skeleton-size"></div>
          <div class="skeleton-size"></div>
        </div>
        <div style="display: flex; gap: 16px; margin-top: 24px;">
          <div class="skeleton-button" style="flex: 1;"></div>
          <div class="skeleton-button" style="flex: 1;"></div>
        </div>
      </div>
    </div>
  `;
}

/**
 * Generate skeleton text lines
 * @param {number} lines - Number of text lines
 * @param {Array<string>} widths - Array of width classes ('short', 'medium', 'long')
 * @returns {string} HTML string
 */
function generateSkeletonText(lines = 3, widths = ['long', 'medium', 'short']) {
  return Array(lines).fill(0).map((_, i) => {
    const width = widths[i % widths.length];
    return `<div class="skeleton-text ${width}"></div>`;
  }).join('');
}

/**
 * Show skeleton loading in a container
 * @param {HTMLElement} container - Container element
 * @param {string} type - Type of skeleton ('products', 'blog', 'wishlist', 'detail', 'text')
 * @param {number} count - Number of items (for grid types)
 */
function showSkeleton(container, type = 'products', count = 8) {
  if (!container) return;
  
  let html = '';
  
  switch(type) {
    case 'products':
      html = `<div class="skeleton-grid">${generateSkeletonProducts(count)}</div>`;
      break;
    case 'blog':
      html = `<div class="skeleton-grid">${generateSkeletonBlog(count)}</div>`;
      break;
    case 'wishlist':
      html = `<div class="skeleton-grid">${generateSkeletonWishlist(count)}</div>`;
      break;
    case 'detail':
      html = generateSkeletonProductDetail();
      break;
    case 'text':
      html = generateSkeletonText(count);
      break;
    default:
      html = generateSkeletonProducts(count);
  }
  
  container.innerHTML = html;
  container.classList.remove('fade-in');
}

/**
 * Hide skeleton and show content with fade-in animation
 * @param {HTMLElement} container - Container element
 * @param {string} content - HTML content to show
 */
function hideSkeleton(container, content) {
  if (!container) return;
  
  container.innerHTML = content;
  container.classList.add('fade-in');
}

// Export for use in other scripts
if (typeof window !== 'undefined') {
  window.SkeletonLoader = {
    generateSkeletonProducts,
    generateSkeletonBlog,
    generateSkeletonWishlist,
    generateSkeletonProductDetail,
    generateSkeletonText,
    showSkeleton,
    hideSkeleton
  };
}
